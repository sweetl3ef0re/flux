<?php if (!defined('FLUX_ROOT')) exit; ?>
    <?php if ($params->get('module') != 'main'):?>
        </div>
    <?php endif ?>
</div>
					</div>
				</div>
				<div id="ContentBottomBG"></div>
			</div>
			<div id="RightContent">
				<div><a href="<?php echo $this->url('main', 'index') ?>" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;btn_download&#39;,&#39;&#39;,&#39;<?php echo $this->themePath('img/btn_download_over.png')?>&#39;,1)" onfocus="this.blur();"><img src="<?php echo $this->themePath('img/btn_download_out.png') ?>" name="btn_download" width="165" height="153" border="0" id="btn_download"></a></div>
				<div><img src="<?php echo $this->themePath('img/mc_quiklinks.png') ?>" width="165" height="44" border="0"></div>
				<div><a href="<?php echo $this->url('main', 'index') ?>" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;btn_quicklinks01&#39;,&#39;&#39;,&#39;http://www.playragnarok.com/images/Master/quick_item_over.png&#39;,1)" onfocus="this.blur();"><img src="<?php echo $this->themePath('img/quick_item_out.png') ?>" name="btn_quicklinks01" width="165" height="22" border="0" id="btn_quicklinks01"></a></div>
				<div><a href="./forums" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;btn_quicklinks02&#39;,&#39;&#39;,&#39;http://www.playragnarok.com/images/Master/quick_forum_over.png&#39;,1)" onfocus="this.blur();"><img src="<?php echo $this->themePath('img/quick_forum_out.png') ?>" name="btn_quicklinks02" width="165" height="22" border="0" id="btn_quicklinks02"></a></div>
				<div><a href="<?php echo $this->url('main', 'index') ?>" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage(&#39;btn_quicklinks03&#39;,&#39;&#39;,&#39;http://www.playragnarok.com/images/Master/quick_purchase_over.png&#39;,1)" onfocus="this.blur();"><img src="<?php echo $this->themePath('img/quick_purchase_out.png') ?>" name="btn_quicklinks03" width="165" height="22" border="0" id="btn_quicklinks03"></a></div>
				<div><img src="<?php echo $this->themePath('img/bg_quickB.png') ?>" width="165" height="66" border="0"></div>
				<div><img src="<?php echo $this->themePath('img/mc_updatestitle.png') ?>" width="165" height="43" border="0"></div>
				<div class="bannercontainer">
					<div class="banner"><a href="<?php echo $this->url('main', 'index') ?>" onfocus="this.blur();"><img src="<?php echo $this->themePath('img/20130603_Eclage.jpg') ?>" width="120" height="200" border="0"></a></div>
				</div>
				<div><img src="<?php echo $this->themePath('img/mc_eventstitle.png') ?>" width="165" height="43" border="0"></div>
				<div class="bannercontainer">
					<div class="banner"><a name="ChangingLink" id="ChangingLink" href="<?php echo $this->url('main', 'index') ?>" target="_blank" onfocus="this.blur()"><img name="ChangingPix" id="ChangingPix" width="120" height="200" border="0" src="<?php echo $this->themePath('img/20141210_LevelCap.jpg') ?>"></a></div>
				</div>
				<div class="bannerConutField">
				
				<!-- Start Banner Count buttons  -->
					<div class="countBtn"></div>
			   	<!--<div class="countBtn"><a href="#" onmouseout="delayPix()" onmouseover="MM_swapImage('bc5','','<?php echo $this->themePath('img/btn_bannerC5_over.png')?>',0); slideshow(5)" onfocus="this.blur()" ><img src="<?php echo $this->themePath('img/btn_bannerC5_out.png') ?>" name="bc5" width="16" height="16" border="0" id="bc5" /></a></div>
					<div class="countBtn"><a href="#" onmouseout="delayPix()" onmouseover="MM_swapImage('bc4','','<?php echo $this->themePath('img/btn_bannerC4_over.png')?>',0); slideshow(4)" onfocus="this.blur()" ><img src="<?php echo $this->themePath('img/btn_bannerC4_out.png') ?>" name="bc4" width="16" height="16" border="0" id="bc4" /></a></div>-->
					
					<div class="countBtn"><a href="" onmouseout="delayPix()" onmouseover="MM_swapImage(&#39;bc3&#39;,&#39;&#39;,&#39;<?php echo $this->themePath('img/btn_bannerC3_over.png')?>&#39;,0); slideshow(3)" onfocus="this.blur()"><img src="<?php echo $this->themePath('img/btn_bannerC3_out.png') ?>" name="bc3" width="16" height="16" border="0" id="bc3"></a></div>				
					<div class="countBtn"><a href="" onmouseout="delayPix()" onmouseover="MM_swapImage(&#39;bc2&#39;,&#39;&#39;,&#39;<?php echo $this->themePath('img/btn_bannerC2_over.png')?>&#39;,0); slideshow(2)" onfocus="this.blur()"><img src="<?php echo $this->themePath('img/btn_bannerC2_out.png') ?>" name="bc2" width="16" height="16" border="0" id="bc2"></a></div>
					<div class="countBtn"><a href="" onmouseout="delayPix()" onmouseover="MM_swapImage(&#39;bc1&#39;,&#39;&#39;,&#39;<?php echo $this->themePath('img/btn_bannerC1_over.png')?>&#39;,0); slideshow(1)" onfocus="this.blur()"><img src="<?php echo $this->themePath('img/btn_bannerC1_over.png') ?>" name="bc1" width="16" height="16" border="0" id="bc1"></a></div>	
					
				<!-- End Banner Count buttons -->
				
				</div>
				<div><img src="<?php echo $this->themePath('img/bg_rightcontentB.png') ?>" width="165" height="112" border="0"></div>
			</div>
			<div style="height:20px;"></div>
			<div id="Footer">
				<div class="line"></div>
				<div>
					<div class="gravityLogo"><img src="<?php echo $this->themePath('img/logo_gravity.png') ?>" width="147" height="37" border="0"></div>
					<div class="copyRight">
					  <a href="#" onclick="javascript:window.open(&#39;#&#39;, &#39;paypopOpen&#39;,&#39;width=570,height=700,statusbar=0,scrollbars=yes&#39;)" onfocus="this.blur()">Privacy Policy</a> | <a href="javascript:;" onclick="javascript:window.open(&#39;#&#39;, &#39;paypopOpen&#39;,&#39;width=570,height=700,statusbar=0,scrollbars=yes&#39;)" onfocus="this.blur()">User Agreement</a> | <a href="javascript:;" onclick="javascript:window.open(&#39;#&#39;, &#39;paypopOpen&#39;,&#39;width=570,height=700,statusbar=0,scrollbars=yes&#39;)" onfocus="this.blur()">Account Policy</a><br>
		
					  &copy; 2012 Gravity Interactive Inc. All Rights Reserved.<br />
				<?php if (count(Flux::$appConfig->get('ThemeName', false)) > 1): ?>
					<span>Theme:
						<select name="preferred_theme" onchange="updatePreferredTheme(this)">
						<?php foreach (Flux::$appConfig->get('ThemeName', false) as $themeName): ?>
							<option value="<?php echo htmlspecialchars($themeName) ?>"<?php if ($session->theme == $themeName) echo ' selected="selected"' ?>><?php echo htmlspecialchars($themeName) ?></option>
						<?php endforeach ?>
						</select>
					</span>
					<form action="<?php echo $this->urlWithQs ?>" method="post" name="preferred_theme_form" style="display: none">
						<input type="hidden" name="preferred_theme" value="" />
					</form>
				<?php endif ?></div>
					<!--<div class="privacyCertified"><img src="<?php echo $this->themePath('img/privacy_certified.jpg')?>" width="117" height="44" border="0" /></div>-->
					<div class="esrb"><img src="<?php echo $this->themePath('img/esrb.gif') ?>" width="135" height="73" border="0"></div>
				</div>
			</div>
		</div>
		</div>
	</div>

<script type="text/javascript">
	$.swapImage(".swapImage");
	$.swapImage(".swapImageClick", true, true, "click");
	$.swapImage(".swapImageDoubleClick", true, true, "dblclick");
	$.swapImage(".swapImageSingleClick", true, false, "click");
	$.swapImage(".swapImageDisjoint");
</script>

<script type="text/javascript">

function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}

</script>
           <script type="text/javascript">

                                var scrollerwidth='335px'
                                var scrollerheight='100px'
                                var pausebetweenimages=3000

                                var slideimages=new Array()
                                
                                slideimages[0] = '<div class="itemcontainer"><div class="thumb" ><a href="http://www.playragnarok.com/kafrashop/detail.aspx?i=195" onfocus="this.blur()" ><img src="http://img.playragnarok.com/kafrashop/gym_pass.bmp" border=0 ></a></div><div class="text">Heavy Lifter Box</div></div><div class="itemcontainer"><div class="thumb" ><a href="http://www.playragnarok.com/kafrashop/detail.aspx?i=203" onfocus="this.blur()" ><img src="http://img.playragnarok.com/kafrashop/Job Battle Manual Box.bmp" border=0 ></a></div><div class="text">Job Battle Manu...</div></div><div class="itemcontainer"><div class="thumb" ><a href="http://www.playragnarok.com/kafrashop/detail.aspx?i=247" onfocus="this.blur()" ><img src="http://img.playragnarok.com/kafrashop/clothing_dye(1).jpg" border=0 ></a></div><div class="text">Omni Clothing Dye</div></div>';slideimages[1] = '<div class="itemcontainer"><div class="thumb" ><a href="http://www.playragnarok.com/kafrashop/detail.aspx?i=252" onfocus="this.blur()" ><img src="http://img.playragnarok.com/kafrashop/acidbomb_50_pack.bmp" border=0 ></a></div><div class="text">Acid Bomb 50 Box</div></div><div class="itemcontainer"><div class="thumb" ><a href="http://www.playragnarok.com/kafrashop/detail.aspx?i=259" onfocus="this.blur()" ><img src="http://img.playragnarok.com/kafrashop/costumehatpack.bmp" border=0 ></a></div><div class="text">Alora\'s Costume...</div></div><div class="itemcontainer"><div class="thumb" ><a href="http://www.playragnarok.com/kafrashop/detail.aspx?i=260" onfocus="this.blur()" ><img src="http://img.playragnarok.com/kafrashop/Enriched.Oridecon(1).jpg" border=0 ></a></div><div class="text">Enriched Oridec...</div></div>';slideimages[2] = '<div class="itemcontainer"><div class="thumb" ><a href="http://www.playragnarok.com/kafrashop/detail.aspx?i=261" onfocus="this.blur()" ><img src="http://img.playragnarok.com/kafrashop/Enriched1.Elunium(1).jpg" border=0 ></a></div><div class="text">Enriched Eluniu...</div></div><div class="itemcontainer"><div class="thumb" ><a href="http://www.playragnarok.com/kafrashop/detail.aspx?i=262" onfocus="this.blur()" ><img src="http://img.playragnarok.com/kafrashop/AdventurePack.jpg" border=0 ></a></div><div class="text">Start your Jour...</div></div><div class="itemcontainer"><div class="thumb" ><a href="http://www.playragnarok.com/kafrashop/detail.aspx?i=264" onfocus="this.blur()" ><img src="http://img.playragnarok.com/kafrashop/stun-star-eyepatch.bmp" border=0 ></a></div><div class="text">Stunning Star E...</div></div>';
                                
                                var ie=document.all
                                var dom=document.getElementById

                                if (slideimages.length>2)
                                i=2
                                else
                                i=0

                                function move1(whichlayer){
                                tlayer=eval(whichlayer)
                                if (tlayer.top>0&&tlayer.top<=5){
                                tlayer.top=0
                                setTimeout("move1(tlayer)",pausebetweenimages)
                                setTimeout("move2(document.main.document.second)",pausebetweenimages)
                                return
                                }
                                if (tlayer.top>=tlayer.document.height*-1){
                                tlayer.top-=5
                                setTimeout("move1(tlayer)",20)
                                }
                                else{
                                tlayer.top=parseInt(scrollerheight)
                                tlayer.document.write(slideimages[i])
                                tlayer.document.close()
                                if (i==slideimages.length-1)
                                i=0
                                else
                                i++
                                }
                                }

                                function move2(whichlayer){
                                tlayer2=eval(whichlayer)
                                if (tlayer2.top>0&&tlayer2.top<=5){
                                tlayer2.top=0
                                setTimeout("move2(tlayer2)",pausebetweenimages)
                                setTimeout("move1(document.main.document.first)",pausebetweenimages)
                                return
                                }
                                if (tlayer2.top>=tlayer2.document.height*-1){
                                tlayer2.top-=5
                                setTimeout("move2(tlayer2)",20)
                                }
                                else{
                                tlayer2.top=parseInt(scrollerheight)
                                tlayer2.document.write(slideimages[i])
                                tlayer2.document.close()
                                if (i==slideimages.length-1)
                                i=0
                                else
                                i++
                                }
                                }

                                function move3(whichdiv){
                                tdiv=eval(whichdiv)
                                if (parseInt(tdiv.style.top)>0&&parseInt(tdiv.style.top)<=5){
                                tdiv.style.top=0+"px"
                                setTimeout("move3(tdiv)",pausebetweenimages)
                                setTimeout("move4(second2_obj)",pausebetweenimages)
                                return
                                }
                                if (parseInt(tdiv.style.top)>=tdiv.offsetHeight*-1){
                                tdiv.style.top=parseInt(tdiv.style.top)-5+"px"
                                setTimeout("move3(tdiv)",20)
                                }
                                else{
                                tdiv.style.top=scrollerheight
                                tdiv.innerHTML=slideimages[i]
                                if (i==slideimages.length-1)
                                i=0
                                else
                                i++
                                }
                                }

                                function move4(whichdiv){
                                tdiv2=eval(whichdiv)
                                if (parseInt(tdiv2.style.top)>0&&parseInt(tdiv2.style.top)<=5){
                                tdiv2.style.top=0+"px"
                                setTimeout("move4(tdiv2)",pausebetweenimages)
                                setTimeout("move3(first2_obj)",pausebetweenimages)
                                return
                                }
                                if (parseInt(tdiv2.style.top)>=tdiv2.offsetHeight*-1){
                                tdiv2.style.top=parseInt(tdiv2.style.top)-5+"px"
                                setTimeout("move4(second2_obj)",20)
                                }
                                else{
                                tdiv2.style.top=scrollerheight
                                tdiv2.innerHTML=slideimages[i]
                                if (i==slideimages.length-1)
                                i=0
                                else
                                i++
                                }
                                }

                                function startscroll(){
                                if (ie||dom){
                                first2_obj=ie? first2 : document.getElementById("first2")
                                second2_obj=ie? second2 : document.getElementById("second2")
                                move3(first2_obj)
                                second2_obj.style.top=scrollerheight
                                second2_obj.style.visibility='visible'
                                }
                                else if (document.layers){
                                document.main.visibility='show'
                                move1(document.main.document.first)
                                document.main.document.second.top=parseInt(scrollerheight)+5
                                document.main.document.second.visibility='show'
                                }
                                }


				<ilayer id="main" width="&amp;{scrollerwidth};" height="&amp;{scrollerheight};" visibility="hide"> <layer id="first" left="0" top="1" width="&amp;{scrollerwidth};">
				<script language="JavaScript1.2">
                                if (document.layers)
                                document.write(slideimages[0])
                                </script>
				</layer><layer id="second" left="0" top="0" width="&amp;{scrollerwidth};" visibility="hide">
				<script language="JavaScript1.2">
                                if (document.layers)
                                document.write(slideimages[dyndetermine=(slideimages.length==1)? 0 : 1])
                                </script>
				</layer></ilayer>
				<script language="JavaScript1.2">
                                if (ie||dom){
                                document.writeln('<div id="main2" style="position:relative;width:'+scrollerwidth+';height:'+scrollerheight+';overflow:hidden;">')
                                document.writeln('<div style="position:absolute;width:'+scrollerwidth+';height:'+scrollerheight+';clip:rect(0 '+scrollerwidth+' '+scrollerheight+' 0);left:0px;top:0px">')
                                document.writeln('<div id="first2" style="position:absolute;width:'+scrollerwidth+';left:0px;top:1px;">')
                                document.write(slideimages[0])
                                document.writeln('</div>')
                                document.writeln('<div id="second2" style="position:absolute;width:'+scrollerwidth+';left:0px;top:0px;visibility:hidden">')
                                document.write(slideimages[dyndetermine=(slideimages.length==1)? 0 : 1])
                                document.writeln('</div>')
                                document.writeln('</div>')
                                document.writeln('</div>')
                                }

                                </script>
		<script type="text/javascript">
			$(document).ready(function(){
				var inputs = 'input[type=text],input[type=password],input[type=file]';
				$(inputs).focus(function(){
					$(this).css({
						'background-color': '#f9f5e7',
						'border-color': '#dcd7c7',
						'color': '#726c58'
					});
				});
				$(inputs).blur(function(){
					$(this).css({
						'backgroundColor': '#ffffff',
						'borderColor': '#dddddd',
						'color': '#444444'
					}, 500);
				});
				$('.menuitem a').hover(
					function(){
						$(this).fadeTo(200, 0.85);
						$(this).css('cursor', 'pointer');
					},
					function(){
						$(this).fadeTo(150, 1.00);
						$(this).css('cursor', 'normal');
					}
				);
				$('.money-input').keyup(function() {
					var creditValue = parseInt($(this).val() / <?php echo Flux::config('CreditExchangeRate') ?>, 10);
					if (isNaN(creditValue))
						$('.credit-input').val('?');
					else
						$('.credit-input').val(creditValue);
				}).keyup();
				$('.credit-input').keyup(function() {
					var moneyValue = parseFloat($(this).val() * <?php echo Flux::config('CreditExchangeRate') ?>);
					if (isNaN(moneyValue))
						$('.money-input').val('?');
					else
						$('.money-input').val(moneyValue.toFixed(2));
				}).keyup();
				
				// In: js/flux.datefields.js
				processDateFields();
			});
			
			function reload(){
				window.location.href = '<?php echo $this->url ?>';
			}
		</script>
		
		<script type="text/javascript">
			function updatePreferredServer(sel){
				var preferred = sel.options[sel.selectedIndex].value;
				document.preferred_server_form.preferred_server.value = preferred;
				document.preferred_server_form.submit();
			}
			
			function updatePreferredTheme(sel){
				var preferred = sel.options[sel.selectedIndex].value;
				document.preferred_theme_form.preferred_theme.value = preferred;
				document.preferred_theme_form.submit();
			}

			// Preload spinner image.
			var spinner = new Image();
			spinner.src = '<?php echo $this->themePath('img/spinner.gif') ?>';
			
			function refreshSecurityCode(imgSelector){
				$(imgSelector).attr('src', spinner.src);
				
				// Load image, spinner will be active until loading is complete.
				var clean = <?php echo Flux::config('UseCleanUrls') ? 'true' : 'false' ?>;
				var image = new Image();
				image.src = "<?php echo $this->url('captcha') ?>"+(clean ? '?nocache=' : '&nocache=')+Math.random();
				
				$(imgSelector).attr('src', image.src);
			}
			function toggleSearchForm()
			{
				//$('.search-form').toggle();
				$('.search-form').slideToggle('fast');
			}
		</script>
		
		<?php if (Flux::config('EnableReCaptcha') && Flux::config('ReCaptchaTheme')): ?>
		<script type="text/javascript">
			 var RecaptchaOptions = {
			    theme : '<?php echo Flux::config('ReCaptchaTheme') ?>'
			 };
		</script>
		<?php endif ?>
		<!--[if lt IE 9]>
		<script src="<?php echo $this->themePath('js/ie9.js') ?>" type="text/javascript"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/flux.unitpngfix.js') ?>"></script>
		<![endif]-->
		<script type="text/javascript" src="<?php echo $this->themePath('js/jquery.metadata.min.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/jquery.swapimage.min.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/btnoverout.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/rotatingbanner.js') ?>"></script>
	</body>
</html>